// // Make the DIV element draggable:
// start = () => {
//      wwindow = document.getElementById("window1");
//      dragElement(wwindow);
// }

// function dragElement(elmnt) {
//   var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

//   elmnt.children[0].onmousedown = dragMouseDown;

//   function dragMouseDown(e) {
//     e = e || window.event;
//     e.preventDefault();
//     // get the mouse cursor position at startup:
//     pos3 = e.clientX;
//     pos4 = e.clientY;
//     document.onmouseup = closeDragElement;
//     // call a function whenever the cursor moves:
//     document.onmousemove = elementDrag;
//   }

//   function elementDrag(e) {
//     e = e || window.event;
//     e.preventDefault();
//     // calculate the new cursor position:
//     pos1 = pos3 - e.clientX;
//     pos2 = pos4 - e.clientY;
//     pos3 = e.clientX;
//     pos4 = e.clientY;
//     // set the element"s new position:
//     elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
//     elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
//   }

//   function closeDragElement() {
//     // stop moving when mouse button is released:
//     document.onmouseup = null;
//     document.onclick = null;
//     document.onmousemove = null;
//   }
// }


start = () => {
     // target elements with the "draggable" class
     interact(".window")
          .draggable({
               // enable inertial throwing
               inertia: false,
               // keep the element within the area of it"s parent
               modifiers: [
                    interact.modifiers.restrictRect({
                         // restriction: "parent",
                         endOnly: true
                    })
               ],
               // enable autoScroll
               autoScroll: true,

               // call this function on every dragmove event
               onmove: dragMoveListener,
               // call this function on every dragend event
               onend: function (event) {
                    var textEl = event.target.querySelector("p")

                    textEl && (textEl.textContent =
                         "moved a distance of " +
                         (Math.sqrt(Math.pow(event.pageX - event.x0, 2) +
                              Math.pow(event.pageY - event.y0, 2) | 0))
                              .toFixed(2) + "px")
               }
          })

     function dragMoveListener(event) {
          var target = event.target
          // keep the dragged position in the data-x/data-y attributes
          var x = (parseFloat(target.getAttribute("data-x")) || 0) + event.dx
          var y = (parseFloat(target.getAttribute("data-y")) || 0) + event.dy

          // translate the element
          target.style.webkitTransform =
               target.style.transform =
               "translate(" + x + "px, " + y + "px)"

          // update the posiion attributes
          target.setAttribute("data-x", x)
          target.setAttribute("data-y", y)
     }
     
     var move_restriction = document.getElementById("move_bounds");
     var element = document.getElementById("icon1")
     var x = 0; var y = 0

     interact(".desktop-icon")
          .draggable({
               modifiers: [
                    interact.modifiers.snap({
                         targets: [
                              interact.createSnapGrid({ x: 80, y: 100 })
                         ],
                         range: Infinity,
                         endOnly: true,
                         relativePoints: [{ x: 0, y: 0 }]
                    }),
                    interact.modifiers.restrict({
                         restriction: move_restriction,
                         // elementRect: { top: 0, left: 0, bottom: 1, right: 1 },
                         endOnly: true
                    })
               ],
               inertia: false
          })
          .on("dragmove", function (event) {
               x += event.dx
               y += event.dy

               event.target.style.webkitTransform =
                    event.target.style.transform =
                    "translate(" + x + "px, " + y + "px)"
          })

     // this is used later in the resizing and gesture demos
     // window.dragMoveListener = dragMoveListener
}